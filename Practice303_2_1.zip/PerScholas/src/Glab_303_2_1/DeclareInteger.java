package Glab_303_2_1;

public class DeclareInteger {
    public static void main(String[] args) {
        int x = 5;
        int y = 6;
        double q = (double)y/x;//converting int to double
        System.out.println(q);
         q =(double)y;
        System.out.println(q);

    }
}


