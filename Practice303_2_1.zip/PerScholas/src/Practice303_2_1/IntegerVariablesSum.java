package Practice303_2_1;

public class IntegerVariablesSum {
    public static void main(String[] args) {
        int a = 5;
        int b = 10;
        int result = a+b;
        System.out.println("The sum of two Integer a and b is : " +result);
    }
}
