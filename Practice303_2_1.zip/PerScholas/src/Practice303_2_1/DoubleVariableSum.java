package Practice303_2_1;

public class DoubleVariableSum {
    public static void main(String[] args) {
        double a = 2.5;
        double b = 5.5;
        double sum = a+b;
        System.out.println(" The sum of double a and double b is : " +sum);
    }
}
