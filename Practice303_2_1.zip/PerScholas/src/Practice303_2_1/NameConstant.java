package Practice303_2_1;

public class NameConstant {
    public static void main(String[] args) {
        final double pi = 3.14;
        double r = 4.0;
        double area = pi*r*r;
        System.out.println("The area of circle is : " +area);
    }
}
