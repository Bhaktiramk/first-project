package Practice303_2_1;

public class DivideDouble {
    public static void main(String[] args) {
        double a = 7.8;
        double b = 9.9;
        double result = b > a? b/a: b/a;
        System.out.println(result);
        int intresult = (int)result;
        System.out.println(intresult);
    }
}
