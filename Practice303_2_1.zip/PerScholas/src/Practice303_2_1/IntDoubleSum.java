package Practice303_2_1;

public class IntDoubleSum {
    public static void main(String[] args) {
        int a = 10;
        double b = 3.6;
        double sum = a+b;
        System.out.println("The sum of the a Int and b double is : " +sum);
    }
}
