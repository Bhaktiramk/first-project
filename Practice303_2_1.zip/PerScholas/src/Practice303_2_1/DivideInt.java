package Practice303_2_1;

public class DivideInt {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;
        double c = (double)b/a;//converting int to double
        System.out.println("The result is : " +c);
        c =(double)b;
        System.out.println("The result is : " +c);
    }
}
