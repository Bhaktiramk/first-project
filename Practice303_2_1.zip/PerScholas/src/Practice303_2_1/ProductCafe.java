package Practice303_2_1;

public class ProductCafe {
    public static void main(String[] args) {
         double coffee = 5.6;
         double cappuccino = 7.8;
         double greenTea = 6.4;
int coffeeQ = 3;
int cappuccinoQ = 4;
int greenteaQ = 2;
double subtotal = (coffee*coffeeQ)+(cappuccino*cappuccinoQ)+(greenTea*greenteaQ);
final double SALES_TAX = 0.07;
double totalSale = subtotal + (subtotal * SALES_TAX);
        System.out.println("Subtotal: " +subtotal);
        System.out.println("Totalsale: " +totalSale);
    }
}
